from .leanhtml import compress_html

__all__ = ['compress_html']
